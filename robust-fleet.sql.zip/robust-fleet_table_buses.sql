
-- --------------------------------------------------------

--
-- Table structure for table `buses`
--

DROP TABLE IF EXISTS `buses`;
CREATE TABLE IF NOT EXISTS `buses` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `buses`
--

INSERT INTO `buses` (`id`, `name`, `created_at`, `updated_at`) VALUES
(2, 'Alex-Cairo', '2022-07-08 07:09:55', '2022-07-08 07:09:55'),
(3, 'Cairo-Alex', '2022-07-08 07:10:14', '2022-07-08 07:10:14'),
(4, 'Cairo-Tanta', '2022-07-08 07:10:27', '2022-07-08 07:10:27'),
(5, 'Cairo-Sohag', '2022-07-08 07:10:46', '2022-07-08 07:10:46');
