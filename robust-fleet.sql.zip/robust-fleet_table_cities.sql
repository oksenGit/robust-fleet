
-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

DROP TABLE IF EXISTS `cities`;
CREATE TABLE IF NOT EXISTS `cities` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Cairo', '2022-07-08 06:56:09', '2022-07-08 06:56:09'),
(2, 'Tanta', '2022-07-08 06:56:16', '2022-07-08 06:56:16'),
(3, 'Alexanderia', '2022-07-08 06:56:27', '2022-07-08 06:56:27'),
(4, 'Sohag', '2022-07-08 07:12:51', '2022-07-08 07:12:51');
