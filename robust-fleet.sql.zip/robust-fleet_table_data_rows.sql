
-- --------------------------------------------------------

--
-- Table structure for table `data_rows`
--

DROP TABLE IF EXISTS `data_rows`;
CREATE TABLE IF NOT EXISTS `data_rows` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `data_type_id` int(10) UNSIGNED NOT NULL,
  `field` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `browse` tinyint(1) NOT NULL DEFAULT '1',
  `read` tinyint(1) NOT NULL DEFAULT '1',
  `edit` tinyint(1) NOT NULL DEFAULT '1',
  `add` tinyint(1) NOT NULL DEFAULT '1',
  `delete` tinyint(1) NOT NULL DEFAULT '1',
  `details` text COLLATE utf8mb4_unicode_ci,
  `order` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `data_rows_data_type_id_foreign` (`data_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `data_rows`
--

INSERT INTO `data_rows` (`id`, `data_type_id`, `field`, `type`, `display_name`, `required`, `browse`, `read`, `edit`, `add`, `delete`, `details`, `order`) VALUES
(1, 1, 'id', 'number', 'ID', 1, 0, 0, 0, 0, 0, NULL, 1),
(2, 1, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, NULL, 2),
(3, 1, 'email', 'text', 'Email', 1, 1, 1, 1, 1, 1, NULL, 3),
(4, 1, 'password', 'password', 'Password', 1, 0, 0, 1, 1, 0, NULL, 4),
(5, 1, 'remember_token', 'text', 'Remember Token', 0, 0, 0, 0, 0, 0, NULL, 5),
(6, 1, 'created_at', 'timestamp', 'Created At', 0, 1, 1, 0, 0, 0, NULL, 6),
(7, 1, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, NULL, 7),
(8, 1, 'avatar', 'image', 'Avatar', 0, 1, 1, 1, 1, 1, NULL, 8),
(9, 1, 'user_belongsto_role_relationship', 'relationship', 'Role', 0, 1, 1, 1, 1, 0, '{\"model\":\"TCG\\\\Voyager\\\\Models\\\\Role\",\"table\":\"roles\",\"type\":\"belongsTo\",\"column\":\"role_id\",\"key\":\"id\",\"label\":\"display_name\",\"pivot_table\":\"roles\",\"pivot\":0}', 10),
(10, 1, 'user_belongstomany_role_relationship', 'relationship', 'Roles', 0, 1, 1, 1, 1, 0, '{\"model\":\"TCG\\\\Voyager\\\\Models\\\\Role\",\"table\":\"roles\",\"type\":\"belongsToMany\",\"column\":\"id\",\"key\":\"id\",\"label\":\"display_name\",\"pivot_table\":\"user_roles\",\"pivot\":\"1\",\"taggable\":\"0\"}', 11),
(11, 1, 'settings', 'hidden', 'Settings', 0, 0, 0, 0, 0, 0, NULL, 12),
(12, 2, 'id', 'number', 'ID', 1, 0, 0, 0, 0, 0, NULL, 1),
(13, 2, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, NULL, 2),
(14, 2, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, NULL, 3),
(15, 2, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, NULL, 4),
(16, 3, 'id', 'number', 'ID', 1, 0, 0, 0, 0, 0, NULL, 1),
(17, 3, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, NULL, 2),
(18, 3, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, NULL, 3),
(19, 3, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, NULL, 4),
(20, 3, 'display_name', 'text', 'Display Name', 1, 1, 1, 1, 1, 1, NULL, 5),
(21, 1, 'role_id', 'text', 'Role', 1, 1, 1, 1, 1, 1, NULL, 9),
(22, 5, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(23, 5, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, '{}', 2),
(24, 5, 'created_at', 'timestamp', 'Created At', 0, 1, 1, 0, 0, 1, '{}', 3),
(25, 5, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 4),
(26, 6, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(27, 6, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, '{}', 2),
(28, 6, 'created_at', 'timestamp', 'Created At', 0, 1, 1, 0, 0, 0, '{}', 3),
(29, 6, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 4),
(30, 7, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(31, 7, 'bus_id', 'text', 'Bus Id', 1, 1, 1, 1, 1, 1, '{}', 2),
(32, 7, 'created_at', 'timestamp', 'Created At', 0, 1, 1, 0, 0, 0, '{}', 3),
(33, 7, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 4),
(34, 7, 'trip_belongsto_bus_relationship', 'relationship', 'Bus', 1, 1, 1, 1, 1, 1, '{\"model\":\"\\\\App\\\\Models\\\\Bus\",\"table\":\"buses\",\"type\":\"belongsTo\",\"column\":\"bus_id\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"buses\",\"pivot\":\"0\",\"taggable\":\"0\"}', 5),
(53, 12, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(54, 12, 'trip_id', 'text', 'Trip Id', 1, 1, 1, 1, 1, 1, '{}', 2),
(55, 12, 'city_id', 'text', 'City Id', 1, 1, 1, 1, 1, 1, '{}', 3),
(56, 12, 'order', 'number', 'Order', 1, 1, 1, 1, 1, 1, '{}', 4),
(57, 12, 'created_at', 'timestamp', 'Created At', 0, 1, 1, 1, 0, 1, '{}', 5),
(58, 12, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 6),
(59, 12, 'stop_belongsto_trip_relationship', 'relationship', 'trips', 0, 1, 1, 1, 1, 1, '{\"model\":\"\\\\App\\\\Models\\\\Trip\",\"table\":\"trips\",\"type\":\"belongsTo\",\"column\":\"trip_id\",\"key\":\"id\",\"label\":\"id\",\"pivot_table\":\"buses\",\"pivot\":\"0\",\"taggable\":\"0\"}', 7),
(60, 12, 'stop_belongsto_city_relationship', 'relationship', 'cities', 0, 1, 1, 1, 1, 1, '{\"model\":\"\\\\App\\\\Models\\\\City\",\"table\":\"cities\",\"type\":\"belongsTo\",\"column\":\"city_id\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"buses\",\"pivot\":\"0\",\"taggable\":\"0\"}', 8),
(61, 7, 'trip_hasmany_stop_relationship', 'relationship', 'stops', 0, 1, 1, 1, 1, 1, '{\"model\":\"\\\\App\\\\Models\\\\Stop\",\"table\":\"stops\",\"type\":\"hasMany\",\"column\":\"trip_id\",\"key\":\"id\",\"label\":\"city_id\",\"pivot_table\":\"buses\",\"pivot\":\"0\",\"taggable\":\"0\"}', 6),
(62, 14, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(63, 14, 'user_id', 'hidden', 'User Id', 0, 1, 1, 1, 1, 1, '{}', 2),
(64, 14, 'seat_id', 'hidden', 'Seat Id', 1, 1, 1, 1, 1, 1, '{}', 3),
(65, 14, 'departure_city_id', 'hidden', 'Departure City Id', 1, 1, 1, 1, 1, 1, '{}', 4),
(66, 14, 'destination_city_id', 'hidden', 'Destination City Id', 1, 1, 1, 1, 1, 1, '{}', 5),
(67, 14, 'created_at', 'timestamp', 'Created At', 0, 1, 1, 1, 0, 1, '{}', 6),
(68, 14, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 7),
(69, 14, 'reservation_belongsto_seat_relationship', 'relationship', 'Seat ID', 0, 1, 1, 1, 1, 1, '{\"model\":\"\\\\App\\\\Models\\\\Seat\",\"table\":\"seats\",\"type\":\"belongsTo\",\"column\":\"seat_id\",\"key\":\"id\",\"label\":\"id\",\"pivot_table\":\"buses\",\"pivot\":\"0\",\"taggable\":\"0\"}', 8),
(70, 14, 'reservation_belongsto_city_relationship', 'relationship', 'Departure City', 0, 1, 1, 1, 1, 1, '{\"model\":\"\\\\App\\\\Models\\\\City\",\"table\":\"cities\",\"type\":\"belongsTo\",\"column\":\"departure_city_id\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"buses\",\"pivot\":\"0\",\"taggable\":\"0\"}', 9),
(71, 14, 'reservation_belongsto_city_relationship_1', 'relationship', 'Destination City', 0, 1, 1, 1, 1, 1, '{\"model\":\"\\\\App\\\\Models\\\\City\",\"table\":\"cities\",\"type\":\"belongsTo\",\"column\":\"destination_city_id\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"buses\",\"pivot\":\"0\",\"taggable\":\"0\"}', 10);
