
-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `table_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `permissions_key_index` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `key`, `table_name`, `created_at`, `updated_at`) VALUES
(1, 'browse_admin', NULL, '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(2, 'browse_bread', NULL, '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(3, 'browse_database', NULL, '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(4, 'browse_media', NULL, '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(5, 'browse_compass', NULL, '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(6, 'browse_menus', 'menus', '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(7, 'read_menus', 'menus', '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(8, 'edit_menus', 'menus', '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(9, 'add_menus', 'menus', '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(10, 'delete_menus', 'menus', '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(11, 'browse_roles', 'roles', '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(12, 'read_roles', 'roles', '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(13, 'edit_roles', 'roles', '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(14, 'add_roles', 'roles', '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(15, 'delete_roles', 'roles', '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(16, 'browse_users', 'users', '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(17, 'read_users', 'users', '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(18, 'edit_users', 'users', '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(19, 'add_users', 'users', '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(20, 'delete_users', 'users', '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(21, 'browse_settings', 'settings', '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(22, 'read_settings', 'settings', '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(23, 'edit_settings', 'settings', '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(24, 'add_settings', 'settings', '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(25, 'delete_settings', 'settings', '2022-07-06 21:42:27', '2022-07-06 21:42:27'),
(26, 'browse_cities', 'cities', '2022-07-08 02:00:23', '2022-07-08 02:00:23'),
(27, 'read_cities', 'cities', '2022-07-08 02:00:23', '2022-07-08 02:00:23'),
(28, 'edit_cities', 'cities', '2022-07-08 02:00:23', '2022-07-08 02:00:23'),
(29, 'add_cities', 'cities', '2022-07-08 02:00:23', '2022-07-08 02:00:23'),
(30, 'delete_cities', 'cities', '2022-07-08 02:00:23', '2022-07-08 02:00:23'),
(31, 'browse_buses', 'buses', '2022-07-08 02:02:03', '2022-07-08 02:02:03'),
(32, 'read_buses', 'buses', '2022-07-08 02:02:03', '2022-07-08 02:02:03'),
(33, 'edit_buses', 'buses', '2022-07-08 02:02:03', '2022-07-08 02:02:03'),
(34, 'add_buses', 'buses', '2022-07-08 02:02:03', '2022-07-08 02:02:03'),
(35, 'delete_buses', 'buses', '2022-07-08 02:02:03', '2022-07-08 02:02:03'),
(36, 'browse_trips', 'trips', '2022-07-08 02:02:41', '2022-07-08 02:02:41'),
(37, 'read_trips', 'trips', '2022-07-08 02:02:41', '2022-07-08 02:02:41'),
(38, 'edit_trips', 'trips', '2022-07-08 02:02:41', '2022-07-08 02:02:41'),
(39, 'add_trips', 'trips', '2022-07-08 02:02:41', '2022-07-08 02:02:41'),
(40, 'delete_trips', 'trips', '2022-07-08 02:02:41', '2022-07-08 02:02:41'),
(46, 'browse_stops', 'stops', '2022-07-08 04:20:52', '2022-07-08 04:20:52'),
(47, 'read_stops', 'stops', '2022-07-08 04:20:52', '2022-07-08 04:20:52'),
(48, 'edit_stops', 'stops', '2022-07-08 04:20:52', '2022-07-08 04:20:52'),
(49, 'add_stops', 'stops', '2022-07-08 04:20:52', '2022-07-08 04:20:52'),
(50, 'delete_stops', 'stops', '2022-07-08 04:20:52', '2022-07-08 04:20:52'),
(51, 'browse_reservations', 'reservations', '2022-07-08 07:01:33', '2022-07-08 07:01:33'),
(52, 'read_reservations', 'reservations', '2022-07-08 07:01:33', '2022-07-08 07:01:33'),
(53, 'edit_reservations', 'reservations', '2022-07-08 07:01:33', '2022-07-08 07:01:33'),
(54, 'add_reservations', 'reservations', '2022-07-08 07:01:33', '2022-07-08 07:01:33'),
(55, 'delete_reservations', 'reservations', '2022-07-08 07:01:33', '2022-07-08 07:01:33');
