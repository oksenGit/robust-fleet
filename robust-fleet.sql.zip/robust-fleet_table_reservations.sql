
-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

DROP TABLE IF EXISTS `reservations`;
CREATE TABLE IF NOT EXISTS `reservations` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `seat_id` bigint(20) UNSIGNED NOT NULL,
  `departure_city_id` bigint(20) UNSIGNED NOT NULL,
  `destination_city_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reservations_user_id_foreign` (`user_id`),
  KEY `reservations_seat_id_foreign` (`seat_id`),
  KEY `reservations_departure_city_id_foreign` (`departure_city_id`),
  KEY `reservations_destination_city_id_foreign` (`destination_city_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`id`, `user_id`, `seat_id`, `departure_city_id`, `destination_city_id`, `created_at`, `updated_at`) VALUES
(1, NULL, 61, 1, 4, '2022-07-08 07:19:49', '2022-07-08 07:19:49');
