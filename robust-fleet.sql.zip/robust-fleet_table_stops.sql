
-- --------------------------------------------------------

--
-- Table structure for table `stops`
--

DROP TABLE IF EXISTS `stops`;
CREATE TABLE IF NOT EXISTS `stops` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `trip_id` bigint(20) UNSIGNED NOT NULL,
  `city_id` bigint(20) UNSIGNED NOT NULL,
  `order` tinyint(3) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stops_trip_id_foreign` (`trip_id`),
  KEY `stops_city_id_foreign` (`city_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stops`
--

INSERT INTO `stops` (`id`, `trip_id`, `city_id`, `order`, `created_at`, `updated_at`) VALUES
(6, 1, 1, 1, '2022-07-08 07:11:13', '2022-07-08 07:11:13'),
(7, 1, 2, 2, '2022-07-08 07:11:30', '2022-07-08 07:11:30'),
(8, 1, 3, 3, '2022-07-08 07:11:39', '2022-07-08 07:11:39'),
(9, 2, 1, 1, '2022-07-08 07:12:25', '2022-07-08 07:12:25'),
(10, 2, 4, 2, '2022-07-08 07:13:26', '2022-07-08 07:13:26'),
(11, 3, 3, 1, '2022-07-08 07:15:44', '2022-07-08 07:15:44'),
(12, 3, 2, 2, '2022-07-08 07:15:53', '2022-07-08 07:15:53'),
(13, 3, 1, 3, '2022-07-08 07:16:08', '2022-07-08 07:16:08'),
(14, 4, 1, 1, '2022-07-08 07:16:46', '2022-07-08 07:16:46'),
(15, 4, 2, 2, '2022-07-08 07:16:57', '2022-07-08 07:16:57');
