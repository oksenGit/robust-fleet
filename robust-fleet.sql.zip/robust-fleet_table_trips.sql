
-- --------------------------------------------------------

--
-- Table structure for table `trips`
--

DROP TABLE IF EXISTS `trips`;
CREATE TABLE IF NOT EXISTS `trips` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `bus_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `trips_bus_id_foreign` (`bus_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `trips`
--

INSERT INTO `trips` (`id`, `bus_id`, `created_at`, `updated_at`) VALUES
(1, 3, '2022-07-08 07:11:02', '2022-07-08 07:11:02'),
(2, 5, '2022-07-08 07:12:02', '2022-07-08 07:12:02'),
(3, 2, '2022-07-08 07:14:52', '2022-07-08 07:14:52'),
(4, 4, '2022-07-08 07:16:32', '2022-07-08 07:16:32');
